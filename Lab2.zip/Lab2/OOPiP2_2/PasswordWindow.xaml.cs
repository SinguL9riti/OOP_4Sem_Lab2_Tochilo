﻿using System.Windows;

namespace FileStreamExample
{
    public partial class PasswordWindow : Window
    {
        public string Password { get; private set; }

        public PasswordWindow()
        {
            InitializeComponent();
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            // Получаем введенный пароль из PasswordBox
            Password = passwordBox.Password;

            // Закрываем окно с результатом DialogResult = true
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            // Закрываем окно с результатом DialogResult = false
            DialogResult = false;
        }
    }
}
