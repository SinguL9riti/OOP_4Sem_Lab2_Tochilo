﻿using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows;
using Microsoft.Win32;
using MyLib;

namespace FileStreamExample
{
    public partial class MainWindow : Window
    {
        private MyLib.IStream currentStream;
        private Timer timer;
        private bool dataWritten;

        public MainWindow()
        {
            InitializeComponent();
            timer = new Timer(TimeoutCallback, null, Timeout.Infinite, Timeout.Infinite);
        }

        private void OpenMemoryStream_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;

                // Читаем данные из текстового поля
                string data = dataTextBox.Text;

                // Если строка пустая, показываем окно для ввода пароля
                if (string.IsNullOrEmpty(data))
                {
                    PromptForPassword(sender, filePath); // Передаем sender и путь к файлу
                    return;
                }

                FileStream fileStream = File.Open(filePath, FileMode.OpenOrCreate);

                // Создаем декоратор FileStreamDecorator
                currentStream = new FileStreamDecorator(fileStream, TimeSpan.FromMinutes(5), "password123");

                // Преобразуем данные в байтовый массив
                byte[] buffer = Encoding.UTF8.GetBytes(data);

                // Записываем данные в поток
                currentStream.Write(buffer, 0, buffer.Length);
                currentStream.Flush();
            }
        }

        private void OpenBufferedStream_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;

                // Читаем данные из текстового поля
                string data = dataTextBox.Text;

                // Если строка пустая, показываем окно для ввода пароля
                if (string.IsNullOrEmpty(data))
                {
                    PromptForPassword(sender, filePath); // Передаем sender и путь к файлу
                    return;
                }

                FileStream fileStream = File.Open(filePath, FileMode.OpenOrCreate);

                // Создаем BufferedStream
                BufferedStream bufferedStream = new BufferedStream(fileStream);

                // Создаем декоратор BufferedStreamDecorator
                currentStream = new BufferedStreamDecorator(bufferedStream, TimeSpan.FromMinutes(5), "password123");

                // Преобразуем данные в байтовый массив
                byte[] buffer = Encoding.UTF8.GetBytes(data);

                // Записываем данные в поток
                currentStream.Write(buffer, 0, buffer.Length);
                currentStream.Flush();
            }
        }

        private void OpenFileStream_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;

                // Читаем данные из текстового поля
                string data = dataTextBox.Text;

                // Если строка пустая, показываем окно для ввода пароля
                if (string.IsNullOrEmpty(data))
                {
                    PromptForPassword(sender, filePath); // Передаем sender и путь к файлу
                    return;
                }

                FileStream fileStream = File.Open(filePath, FileMode.OpenOrCreate);

                // Создаем декоратор FileStreamDecorator
                currentStream = new FileStreamDecorator(fileStream, TimeSpan.FromMinutes(0.2), "password123");

                // Преобразуем данные в байтовый массив
                byte[] buffer = Encoding.UTF8.GetBytes(data);

                // Записываем данные в поток
                currentStream.Write(buffer, 0, buffer.Length);
                currentStream.Flush();
            }
        }

        private void CloseStream_Click(object sender, RoutedEventArgs e)
        {
            currentStream?.Dispose();
            currentStream = null;
        }

        private void TimeoutCallback(object state)
        {
            if (!dataWritten)
            {
                // Data not written within 5 seconds, prompt for password
                Dispatcher.Invoke(() => PromptForPassword(null, null));
            }
        }

        private void PromptForPassword(object sender, string filePath)
        {
            PasswordWindow passwordWindow = new PasswordWindow();
            if (passwordWindow.ShowDialog() == true)
            {
                string password = passwordWindow.Password;
                if (password == "123")
                {
                    // Password correct, continue writing data
                    WriteDataToStream();
                }
                else
                {
                    MessageBox.Show("Incorrect password!");
                    currentStream?.Dispose();
                    currentStream = null;
                }
            }
        }

        private void WriteDataToStream()
        {
            if (currentStream != null)
            {
                string data = dataTextBox.Text;
                byte[] buffer = Encoding.UTF8.GetBytes(data);
                currentStream.Write(buffer, 0, buffer.Length);
                currentStream.Flush();
                dataWritten = true;
            }
        }

    }
}
