﻿using System;
using System.IO;

namespace MyLib
{
    public class FileStreamDecorator : IStream, IDisposable
    {
        private FileStream fileStream;
        private TimeSpan timeout;
        private string password;

        public FileStreamDecorator(FileStream stream, TimeSpan timeout, string password)
        {
            fileStream = stream;
            this.timeout = timeout;
            this.password = password;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // Освобождение управляемых ресурсов
                fileStream?.Dispose();
            }
        }

        public void Write(byte[] buffer, int offset, int count)
        {
            fileStream.Write(buffer, offset, count);
        }

        public void Flush()
        {
            fileStream.Flush();
        }
    }
}
