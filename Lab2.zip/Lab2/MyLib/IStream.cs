﻿using System;
using System.Runtime.InteropServices.ComTypes;

namespace MyLib
{
    // Общий интерфейс для декораторов потока
    public interface IStream : IDisposable
    {
        void Write(byte[] buffer, int offset, int count);
        void Flush();
    }
}
