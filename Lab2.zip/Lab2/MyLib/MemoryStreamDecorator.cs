﻿using System;
using System.IO;

namespace MyLib
{
    // Пример декоратора MemoryStream
    public class MemoryStreamDecorator : IStream, IDisposable
    {
        private MemoryStream memoryStream;
        private TimeSpan timeout;
        private string password;

        public MemoryStreamDecorator(MemoryStream stream, TimeSpan timeout, string password)
        {
            memoryStream = stream;
            this.timeout = timeout;
            this.password = password;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // Освобождение управляемых ресурсов
                memoryStream?.Dispose();
            }
        }

        public void Write(byte[] buffer, int offset, int count)
        {
            memoryStream.Write(buffer, offset, count);
        }

        public void Flush()
        {
            memoryStream.Flush();
        }
    }
}
